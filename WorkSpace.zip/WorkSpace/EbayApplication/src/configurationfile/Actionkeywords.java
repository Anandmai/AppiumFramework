package configurationfile;
import java.util.concurrent.TimeUnit;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;
import static executionEngine.MainDriver.OR;
import configurationfile.Constants;	
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import io.appium.java_client.android.AndroidDriver;

public class Actionkeywords {

	//public static WebDriver driver;
	private static AndroidDriver driver;
	 
	//public static void openBrowser(){		
		//driver = new FirefoxDriver();
		//}
 
	public static void navigate(){	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//driver.get("http://www.store.demoqa.com");
		driver.get(Constants.URL);
		}
 
	public static void click(String object){
		//driver.findElement(By.xpath(".//*[@id='account']/a")).click();
		driver.findElement(By.xpath(OR.getProperty(object))).click();
		}
 //click by name
	public static void clickbyname(String object){
		//driver.findElement(By.xpath(".//*[@id='account']/a")).click();
		driver.findElement(By.name(OR.getProperty(object))).click();
		}
	
	//click by id
	public static void clickbyid(String object){
		//driver.findElement(By.xpath(".//*[@id='account']/a")).click();
		driver.findElement(By.id(OR.getProperty(object))).click();
		}
	//input data by id
	public static void sendkeysbyID(String object,String data){
		driver.findElement(By.id(OR.getProperty(object))).sendKeys(data); 
		
		}
	//input data by xpath
	public static void sendkeysbyxpath(String object,String data){
		driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data); 
		
		}
	//send keys by name
	public static void sendkeysbyname(String object,String data){
		driver.findElement(By.name(OR.getProperty(object))).sendKeys(data); 
		
		}
	//scroll or swipe function
	public static void scroll(String object , String data){
			
		Dimension dimensions = driver.manage().window().getSize();
		
		for(int i=1; i>4; i++)
		{
			Double screenHeightStart = dimensions.getHeight() * 0.5;

			int scrollStart = screenHeightStart.intValue();

			Double screenHeightEnd = dimensions.getHeight() * 0.2;

			int scrollEnd = screenHeightEnd.intValue();

			driver.swipe(0, scrollStart, 0, scrollEnd, 2000);

		}
	 
	}
	
	
	//Drag function
	public static void drag(String object , String data ,String data1)
	{
		try{
			WebElement el=driver.findElementById(object);
			TouchAction tap=new TouchAction(driver);
			int coordinate1 = Integer.parseInt(data);
			int coordinate2 = Integer.parseInt(data1);
			tap.longPress(el).moveTo(coordinate1, coordinate2).release().perform();
			System.out.println("object dragged");
			
		}
		catch(Exception e){
			System.out.println("object dragged");
		}
	}
	
	
	public static void Tapcoordinates(String object , String data ,String data1)
	{
		try{
			TouchAction Action=new TouchAction(driver);
			int coordinate1 = Integer.parseInt(data);
			int coordinate2 = Integer.parseInt(data1);
			Action.tap(coordinate1, coordinate2);
			System.out.println("Object Tapped");			
		}
		catch(Exception e){
			System.out.println("Object Tapped");
		}
	}
	
	//adb command to enter text
	public static void adbsendkeys(String data) throws IOException
	{
		try{
			Runtime.getRuntime().exec("adb shell input text"+data );
		}
		catch(Exception e){
	
			System.out.println("Unknown exception");
		}
	}
	//screen rotation
	public void rotate(ScreenOrientation data)
	{
//give portrait or Landscape view in data
		driver.rotate(data);
		driver.getOrientation();
		System.out.println("device rotated");
		
	}
	
	public static void waitFor(String object) throws Exception{
		Thread.sleep(5000);
		}
	public static void click_Logout(){
		driver.findElement (By.xpath(".//*[@id='account_logout']/a")).click();
		}
 
	public static void closeBrowser(){
			driver.quit();
		}
}
