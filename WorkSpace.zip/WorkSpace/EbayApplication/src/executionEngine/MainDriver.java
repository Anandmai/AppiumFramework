package executionEngine;


import io.appium.java_client.android.AndroidDriver;
import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import configurationfile.Actionkeywords;
import utility.ExcelUtils;
import configurationfile.Constants;


public class MainDriver {
	  public static Properties OR;
		private static AndroidDriver driver;
		//This is a class object, declared as 'public static'
		//So that it can be used outside the scope of main[] method
		public static Actionkeywords actionKeywords;
		public static String sActionKeyword;
		public static String sPageObject;
		//This is reflection class object, declared as 'public static'
		//So that it can be used outside the scope of main[] method
		public static Method method[];
		public static int iTestStep;
		public static int iTestLastStep;
		public static String sTestCaseID;
		public static String sRunMode;
		public MainDriver() throws NoSuchMethodException, SecurityException{
			actionKeywords = new Actionkeywords();
			//This will load all the methods of the class 'ActionKeywords' in it.
	        //It will be like array of method, use the break point here and do the watch
			method = actionKeywords.getClass().getMethods();
		}
		
		public static void main(String[] args) throws Exception {
			String Path_DataEngine  = Constants.Path_TestData;
			//ExcelUtils.setExcelFile(Constants.Path_TestData);
			ExcelUtils.setExcelFile(Constants.Path_TestData, Path_DataEngine);
			
			// Here we are passing the Excel path and SheetName as arguments to connect with Excel file 
	    	//ExcelUtils.setExcelFile(Path_DataEngine ,Constants.Sheet_TestSteps);
	    	String Path_OR = Constants.path_OR;
	    	
	    	//Creating file system object for Object Repository text/property file
			FileInputStream fs = new FileInputStream(Path_OR);
			//Creating an Object of properties
			OR= new Properties(System.getProperties());
			//Loading all the properties from Object Repository property file in to OR object
			OR.load(fs);
	 
			MainDriver startEngine = new MainDriver();
			startEngine.execute_TestCase();
			
			File classpathRoot = new File(System.getProperty("user.dir"));
			File appDir = new File(classpathRoot, "/Apps/ebay/");
			File app = new File(appDir, "ebay.apk");	 
			DesiredCapabilities capabilities = new DesiredCapabilities();				
			capabilities.setCapability("deviceName", "SamsungS8");
			capabilities.setCapability("platformVersion", "8.0.0");
			capabilities.setCapability("platformName", "Android");
			capabilities.setCapability("app", app.getAbsolutePath());
			capabilities.setCapability("appPackage", "com.ebay.mobile");
			capabilities.setCapability("appActivity", "com.ebay.mobile.activities.Mainactivity");
 
			driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
			driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			Thread.sleep(10000);
			driver.quit();
					
			
		}
		
		
		private void execute_TestCase() throws Exception {
			//This will return the total number of test cases mentioned in the Test cases sheet
	    	int iTotalTestCases = ExcelUtils.getRowCount(Constants.Sheet_TestSteps);
			//This loop will execute number of times equal to Total number of test cases
			for(int iTestcase=1;iTestcase<=iTotalTestCases;iTestcase++){
				//This is to get the Test case name from the Test Cases sheet
				sTestCaseID = ExcelUtils.getCellData(iTestcase, Constants.Col_TestCaseID, Constants.Sheet_TestCases); 
				//This is to get the value of the Run Mode column for the current test case
				sRunMode = ExcelUtils.getCellData(iTestcase, Constants.Col_RunMode,Constants.Sheet_TestCases);
				//This is the condition statement on RunMode value
				if (sRunMode.equals("Yes")){
					//Only if the value of Run Mode is 'Yes', this part of code will execute
					iTestStep = ExcelUtils.getRowContains(sTestCaseID, Constants.Col_TestCaseID, Constants.Sheet_TestSteps);
					iTestLastStep = ExcelUtils.getTestStepsCount(Constants.Sheet_TestSteps, sTestCaseID, iTestStep);
					//This loop will execute number of times equal to Total number of test steps
					for (;iTestStep<=iTestLastStep;iTestStep++){
			    		sActionKeyword = ExcelUtils.getCellData(iTestStep, Constants.Col_ActionKeyword,Constants.Sheet_TestSteps);
			    		sPageObject = ExcelUtils.getCellData(iTestStep, Constants.Col_Pageobject, Constants.Sheet_TestSteps);
			    		execute_Actions();
			    			}
						}
	    			}
	    		}
			 private static void execute_Actions() throws Exception {
					//This is a loop which will run for the number of actions in the Action Keyword class 
					//method variable contain all the method and method.length returns the total number of methods
					for(int i = 0;i < method.length;i++){
						//This is now comparing the method name with the ActionKeyword value got from excel
						if(method[i].getName().equals(sActionKeyword)){
							//In case of match found, it will execute the matched method
							method[i].invoke(actionKeywords,sPageObject);
							//Once any method is executed, this break statement will take the flow outside of for loop
							break;
							}
						}
			 }
}
	    		
